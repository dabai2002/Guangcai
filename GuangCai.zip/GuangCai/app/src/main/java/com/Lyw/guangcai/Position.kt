package com.Lyw.guangcai

data class Position(val name:String , val ImageId: Int) {
}