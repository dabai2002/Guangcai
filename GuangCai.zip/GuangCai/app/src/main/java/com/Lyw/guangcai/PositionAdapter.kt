package com.Lyw.guangcai

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

//设置recyclerView的适配器以及对象的点击事件
class PositionAdapter(val positionList: List<Position>) : RecyclerView.Adapter<PositionAdapter.ViewHolder>() {
    class ViewHolder(view: View) : RecyclerView.ViewHolder(view){
        val positionName = view.findViewById<TextView>(R.id.positionName)
        val positionImage = view.findViewById<ImageView>(R.id.positionImage)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.position_item, parent, false)
        val viewHolder = ViewHolder(view)
        view.setOnClickListener { v ->
            val position = viewHolder.absoluteAdapterPosition
            val name = positionList.get(position).name
            when(name){
                "南田径场" -> {
                    val intent = Intent(v.context, Activity1::class.java)
                    v.context.startActivity(intent)
                }
                "北田径场" -> {
                    val intent = Intent(v.context, Activity2::class.java)
                    v.context.startActivity(intent)
                }
                "图书馆" -> {
                    val intent = Intent(v.context, Activity3::class.java)
                    v.context.startActivity(intent)
                }
                "篮球场" -> {
                    val intent = Intent(v.context, Activity4::class.java)
                    v.context.startActivity(intent)
                }
                "第一食堂" -> {
                    val intent = Intent(v.context, Activity5::class.java)
                    v.context.startActivity(intent)
                }
                "第二食堂" -> {
                    val intent = Intent(v.context, Activity6::class.java)
                    v.context.startActivity(intent)
                }
                "第三食堂" -> {
                    val intent = Intent(v.context, Activity7::class.java)
                    v.context.startActivity(intent)
                }
                "第一教学楼" -> {
                    val intent = Intent(v.context, Activity8::class.java)
                    v.context.startActivity(intent)
                }
                "综合楼" -> {
                    val intent = Intent(v.context, Activity9::class.java)
                    v.context.startActivity(intent)
                }
                "实验楼" -> {
                    val intent = Intent(v.context, Activity10::class.java)
                    v.context.startActivity(intent)
                }

            }
        }


        return viewHolder
    }


    override fun onBindViewHolder(holder: PositionAdapter.ViewHolder, position: Int) {
        val Newposition = positionList[position]
        holder.positionImage.setImageResource(Newposition.ImageId)
        holder.positionName.text = Newposition.name
    }

    override fun getItemCount() = positionList.size
}