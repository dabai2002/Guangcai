package com.Lyw.guangcai

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ListView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    //水果名称和图片数据
    private val positionNames = arrayOf(
        "南田径场",  "北田径场", "图书馆",
        "篮球场", "第一食堂", "第二食堂", "第三食堂",
        "第一教学楼", "综合楼",  "实验楼"
    )
    private val positionImageIds = intArrayOf(
        R.drawable.south_ground,
        R.drawable.north_ground, R.drawable.library,
        R.drawable.basketball_ground, R.drawable.first_canteen,
        R.drawable.second_canteen, R.drawable.third_canteen,
        R.drawable.first_teaching_building, R.drawable.complex_building,
        R.drawable.laboratory_building
    )

    private val positionList = ArrayList<Position>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initItems()
        val layoutManager = LinearLayoutManager(this)
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = layoutManager
        val positionAdapter = PositionAdapter(positionList)
        recyclerView.adapter = positionAdapter
    }

    private fun initItems(){
        for(i in 0..(positionNames.size-1)){
            positionList.add(Position(positionNames[i],positionImageIds[i]))
        }
    }
}